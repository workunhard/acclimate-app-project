Team Members:

Code Workun, A01273371, Set 2B, May 20 2022
Waleed Ur Rehman, A01026033, Set 2B, May 20 2022
Andrew Chu, A00915964, Set 1A, May 20 2022
Jason Lee, A01310130, Set 1A, May 20 2022

This assignment is 95% complete.

-5% for file upload bug where images with purely numeric names do not properly upload

