function loadSkeleton(){
    console.log($('#navbarPlaceholder').load('/text/nav.html'));
    console.log($('#footerPlaceholder').load('/text/footer.html'));
}
loadSkeleton();  

function expand() {
  var nav = document.getElementById("navLinks");
  if (nav.style.display === "block") {
    nav.style.display = "none";
  } else {
    nav.style.display = "block";
  }
}